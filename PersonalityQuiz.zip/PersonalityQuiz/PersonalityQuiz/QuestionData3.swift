//
//  QuestionData3.swift
//  PersonalityQuiz
//
//  Created by Karthikeyan Lakshmana Doss on 2/5/18.
//  Copyright © 2018 Karthikeyan Lakshmana Doss. All rights reserved.
//

import Foundation

struct Question3 {
    var text: String
    var type: ResponseType3
    var answers: [Answer3]
}

enum ResponseType3 {
    case single, multiple, ranged
}

struct Answer3 {
    var text: String
    var type: villainType
}

enum villainType: String {
    case theJoker = "THE JOKER", lexLuthor = "LEX LUTHOR", thanos = "THANOS", loki = "LOKI"
    var definition: String {
        switch self {
        case .theJoker:
            return "Now what hero do you think you are?"
        case .lexLuthor:
            return "Now what hero do you think you are?"
        case .thanos:
            return "Now what hero do you think you are?"
        case .loki:
            return "Now what hero do you think you are?"
        }
    }
}

