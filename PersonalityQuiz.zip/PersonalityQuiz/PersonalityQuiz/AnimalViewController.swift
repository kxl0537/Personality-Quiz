//
//  AnimalViewController.swift
//  PersonalityQuiz
//
//  Created by Karthikeyan Lakshmana Doss on 2/6/18.
//  Copyright © 2018 Karthikeyan Lakshmana Doss. All rights reserved.
//

import UIKit

class AnimalViewController: UIViewController {

    @IBOutlet weak var chickenGIF: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        chickenGIF.loadGif(name: "Chicken")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

    }

}
