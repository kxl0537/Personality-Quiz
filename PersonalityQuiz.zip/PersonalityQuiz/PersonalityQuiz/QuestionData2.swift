//
//  QuestionData2.swift
//  PersonalityQuiz
//
//  Created by Karthikeyan Lakshmana Doss on 2/5/18.
//  Copyright © 2018 Karthikeyan Lakshmana Doss. All rights reserved.
//

import Foundation

struct Question2 {
    var text: String
    var type: ResponseType2
    var answers: [Answer2]
}

enum ResponseType2 {
    case single, multiple, ranged
}

struct Answer2 {
    var text: String
    var type: heroType
}

enum heroType: String {
    case superman = "SUPERMAN", batman = "BATMAN", wonderWoman = "WONDER WOMAN", deadpool = "DEADPOOL", theHulk = "THE HULK"
    var definition: String {
        switch self {
        case .superman:
            return "Now what villain do you think you are?"
        case .batman:
            return "Now what villain do you think you are?"
        case .wonderWoman:
            return "Now what villain do you think you are?"
        case .deadpool:
            return "Now what villain do you think you are?"
        case .theHulk:
            return "Now what villain do you think you are?"
        }
    }
}
