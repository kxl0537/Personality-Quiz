//
//  ResultsViewController.swift
//  PersonalityQuiz
//
//  Created by Karthikeyan Lakshmana Doss on 1/18/18.
//  Copyright © 2018 Karthikeyan Lakshmana Doss. All rights reserved.
//

import UIKit

class ResultsViewController: UIViewController {
    
    @IBOutlet weak var image: UIImageView!
    
    @IBOutlet weak var resultAnswerLabel: UILabel!
    
    @IBOutlet weak var resultDefinitionLabel: UILabel!
    
    var responses: [Answer]!
    
    var responses2: [Answer2]!
    
    var responses3: [Answer3]!

    override func viewDidLoad() {
        super.viewDidLoad()
        calculatePersonalityResult()
        navigationItem.hidesBackButton = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()

    }

    
    func calculatePersonalityResult() {
        
        if responses != nil {
            
        var frequencyOfAnswers: [memeType: Int] = [:]
        let responseTypes = responses.map { $0.type }
        for response in responseTypes {
            frequencyOfAnswers[response] = (frequencyOfAnswers[response]
                ?? 0) + 1
        }
        
        let mostCommonAnswer = frequencyOfAnswers.sorted { $0.1 >
            $1.1 }.first!.key
        
        resultAnswerLabel.text = "You are \(mostCommonAnswer.rawValue)!"
        resultDefinitionLabel.text = mostCommonAnswer.definition
        image.image = UIImage(named: "\(mostCommonAnswer.rawValue)")
            
        } else if responses2 != nil {
            
            var frequencyOfAnswers: [heroType: Int] = [:]
            let responseTypes = responses2.map { $0.type }
            for response in responseTypes {
                frequencyOfAnswers[response] = (frequencyOfAnswers[response]
                    ?? 0) + 1
            }
            
            let mostCommonAnswer = frequencyOfAnswers.sorted { $0.1 >
                $1.1 }.first!.key
            
            resultAnswerLabel.text = "You are \(mostCommonAnswer.rawValue)!"
            resultDefinitionLabel.text = mostCommonAnswer.definition
            image.image = UIImage(named: "\(mostCommonAnswer.rawValue)")
            
        } else if responses3 != nil {
            var frequencyOfAnswers: [villainType: Int] = [:]
            let responseTypes = responses3.map { $0.type }
            for response in responseTypes {
                frequencyOfAnswers[response] = (frequencyOfAnswers[response]
                    ?? 0) + 1
            }
            
            let mostCommonAnswer = frequencyOfAnswers.sorted { $0.1 >
                $1.1 }.first!.key
            
            resultAnswerLabel.text = "You are \(mostCommonAnswer.rawValue)!"
            resultDefinitionLabel.text = mostCommonAnswer.definition 
            image.image = UIImage(named: "\(mostCommonAnswer.rawValue)")
        }

    }
    
}
