//
//  File.swift
//  PersonalityQuiz
//
//  Created by Karthikeyan Lakshmana Doss on 1/18/18.
//  Copyright © 2018 Karthikeyan Lakshmana Doss. All rights reserved.
//

import Foundation

struct Question {
    var text: String
    var type: ResponseType
    var answers: [Answer]
}

enum ResponseType {
    case single, multiple, ranged
}

struct Answer {
    var text: String
    var type: memeType
}

enum memeType: String {
    case ugandanKnuckles = "UGANDAN KNUCKLES", badLuckBrian = "BAD LUCK BRIAN", tidePod = "A TIDE POD", philosoraptor = "THE PHILOSORAPTOR"
    
    var definition: String {
        switch self {
        case .ugandanKnuckles:
            return "You are a confident leader. You know de wey of life."
        case .badLuckBrian:
            return "You try new things, but you constantly have to face obstacles thrown at you by nature."
        case .tidePod:
            return "You may look sweet on the outside, but you can be very dangerous."
        case .philosoraptor:
            return "You are a thinker. You ponder the existence of everything, and appreciate the ironies of nature."
        }
    }
}

/*
 extension Array {
    mutating func shuffle() {
        for _ in 0..<count {
            sort { (_,_) in arc4random() < arc4random() }
        }
    }
}

extension Array {
    mutating func shuffle() {
        for i in 0 ..< (count - 1) {
            let j = Int(arc4random_uniform(UInt32(count - i))) + i
            swapAt(i, j)
        }
    }
}
*/
