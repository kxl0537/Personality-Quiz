//
//  ViewController.swift
//  PersonalityQuiz
//
//  Created by Karthikeyan Lakshmana Doss on 1/17/18.
//  Copyright © 2018 Karthikeyan Lakshmana Doss. All rights reserved.
//

import UIKit

class IntroductionViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}


